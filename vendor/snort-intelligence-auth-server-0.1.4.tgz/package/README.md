# Server adapter

Supply `database`, `secret`, `baseURL`, `trustedOrigins`, `appName`, `sendEmail`, plus optional Google credentials to `createAuthServer`. The consuming server owns `beforeRequest`, `onMfaVerified` and `onMfaFailed` policies. Its context endpoint must publish only safe identity DTOs.

`getSession(headers)` validates a server session. `handle(request)` dispatches only supported authentication endpoints. Enforce bounded bodies and approved-origin CSRF protection at the host boundary. Migrate the generated provider schema before enabling the adapter. Use environment secrets for provider credentials and encryption keys.

No frontend package is required. Any UI can call the mounted HTTPS endpoints directly. Supply `resolveContext({request,getSession})` to serve GET `/context`, or implement that route in your host. Return only an explicit safe DTO; never return the provider session directly. Missing context policy returns 503 rather than granting access. Existing hosts with their own context routes can keep them unchanged.

`trustedIpHeaders` defaults to `[]`. Supply only headers overwritten by your trusted proxy (for example `['cf-connecting-ip']` behind Cloudflare), and review deployment rate limiting. `basePath` defaults to `/api/v1/auth`; the handler rejects paths outside that exact prefix. Configure isolated app credentials, origins, database and cookie prefix for each project. No Aurelia policy, UI or database binding is bundled.
