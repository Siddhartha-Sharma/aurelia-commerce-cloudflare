import {betterAuth} from "better-auth";
import {twoFactor} from "better-auth/plugins";
import {hashPassword,verifyPassword} from "./password.js";

export class AuthServerError extends Error {
  constructor(message, {status = 403, code = "FORBIDDEN"} = {}) {
    super(message);
    this.name = "AuthServerError";
    this.status = status;
    this.code = code;
  }
}

/** Provider adapter. The consuming project supplies persistence, mail and access policy. */
export function createAuthServer({database, secret, baseURL, trustedOrigins, appName,
  cookiePrefix = "snort-auth", google, sendEmail, onMfaVerified = async () => {},
  onMfaFailed = async () => {},
  trustedIpHeaders = [], resolveContext,
  beforeRequest = async () => {}, basePath = "/api/v1/auth"} = {}) {
  if (!database || !secret || secret.length < 32 || !baseURL || !appName || !sendEmail)
    throw new AuthServerError("Authentication is not configured.", {status:503,code:"AUTH_NOT_CONFIGURED"});
  if (!/^\/(?!\/)/.test(basePath) || /[?#\\]/.test(basePath) || basePath.endsWith("/") ||
      !Array.isArray(trustedIpHeaders) || trustedIpHeaders.some(name => typeof name !== "string" || !name.trim()) ||
      (resolveContext !== undefined && typeof resolveContext !== "function"))
    throw new AuthServerError("Authentication integration is not configured.", {status:503,code:"AUTH_NOT_CONFIGURED"});
  const site = new URL(baseURL);
  const development = ["localhost","127.0.0.1"].includes(site.hostname);
  if (!development && site.protocol !== "https:")
    throw new AuthServerError("Authentication requires HTTPS.", {status:503,code:"AUTH_NOT_CONFIGURED"});
  const auth = betterAuth({
    appName, database, secret, baseURL:site.origin, basePath,
    trustedOrigins,
    user:{modelName:"auth_user", deleteUser:{enabled:false}},
    session:{
      modelName:"auth_session", expiresIn:8 * 60 * 60, updateAge:15 * 60,
      cookieCache:{enabled:false},
    },
    account:{
      modelName:"auth_account", encryptOAuthTokens:true,
      accountLinking:{enabled:true, allowDifferentEmails:false, disableImplicitLinking:true},
    },
    verification:{modelName:"auth_verification"},
    emailAndPassword:{
      enabled:true, minPasswordLength:15, maxPasswordLength:128,
      password:{hash:hashPassword,verify:verifyPassword},
      requireEmailVerification:true, autoSignIn:false,
      revokeSessionsOnPasswordReset:true,
      sendResetPassword:({user,url}) => sendEmail({to:user.email,
        subject:"Reset your " + appName + " password",
        text:"Use this link to choose a new password:\n" + url +
          "\n\nIf you did not request this, you can ignore this email."}),
    },
    emailVerification:{
      sendOnSignUp:true, sendOnSignIn:true, autoSignInAfterVerification:false,
      sendVerificationEmail:({user,url}) => sendEmail({to:user.email,
        subject:"Verify your " + appName + " email",
        text:"Verify your email using this link:\n" + url +
          "\n\nIf you did not create this account, do not verify it."}),
    },
    socialProviders:google?.clientId && google?.clientSecret ? {
      google:{clientId:google.clientId, clientSecret:google.clientSecret},
    } : {},
    advanced:{
      cookiePrefix, useSecureCookies:!development,
      defaultCookieAttributes:{httpOnly:true, secure:!development, sameSite:"lax", path:"/"},
      ipAddress:{ipAddressHeaders:trustedIpHeaders},
    },
    rateLimit:{
      enabled:true, storage:"database", modelName:"auth_rate_limit", window:60, max:60,
      customRules:{
        "/sign-in/email":{window:60,max:5},
        "/sign-up/email":{window:60,max:3},
        "/request-password-reset":{window:60,max:3},
        "/send-verification-email":{window:60,max:3},
        "/two-factor/*":{window:60,max:8},
      },
    },
    plugins:[twoFactor({
      issuer:appName, allowPasswordless:true, skipVerificationOnEnable:false,
      schema:{twoFactor:{modelName:"auth_two_factor"}},
      backupCodeOptions:{amount:10,length:12,storeBackupCodes:"encrypted"},
      accountLockout:{enabled:true,maxFailedAttempts:5,durationSeconds:900},
    })],
    telemetry:{enabled:false},
  });

  const getSession = async headers => auth.api.getSession({
    headers, query:{disableCookieCache:true},
  });
  const allowed = new Set([
    "/sign-up/email","/sign-in/email","/sign-in/social","/callback/google",
    "/sign-out","/verify-email","/send-verification-email","/request-password-reset","/reset-password",
    "/two-factor/enable","/two-factor/disable",
    "/two-factor/verify-totp","/two-factor/verify-backup-code","/two-factor/generate-backup-codes",
    "/change-password","/list-sessions","/revoke-session","/revoke-other-sessions","/revoke-sessions",
    "/link-social","/unlink-account","/list-accounts",
  ]);
  return Object.freeze({
    options:auth.options, getSession,
    providers:{emailPassword:true,google:Boolean(google?.clientId && google?.clientSecret)},
    async handle(request) {
      const incoming = new URL(request.url);
      if (incoming.protocol !== "https:" &&
          !(development && ["localhost","127.0.0.1"].includes(incoming.hostname) && incoming.protocol === "http:"))
        return Response.json({error:{code:"HTTPS_REQUIRED",message:"Open the secure HTTPS address to sign in."}},
          {status:403,headers:{"Cache-Control":"no-store"}});
      const path = incoming.pathname.startsWith(basePath + "/") ? incoming.pathname.slice(basePath.length) : null;
      if (!path || (!allowed.has(path) && path !== "/context"))
        return Response.json({error:{code:"NOT_FOUND",message:"Authentication endpoint not found."}}, {status:404});
      try {
        // The backend owns authorization and MFA assurance, regardless of UI framework.
        // An omitted policy must fail closed rather than manufacture access claims.
        if (path === "/context") {
          if (request.method !== "GET")
            return Response.json({error:{code:"METHOD_NOT_ALLOWED",message:"Use GET for session context."}},
              {status:405,headers:{Allow:"GET","Cache-Control":"no-store"}});
          if (!resolveContext)
            throw new AuthServerError("Session context policy is not configured.",{status:503,code:"CONTEXT_NOT_CONFIGURED"});
          const data = await resolveContext({request,getSession});
          return Response.json({data},{headers:{"Cache-Control":"no-store","Referrer-Policy":"no-referrer"}});
        }
        if (["/sign-in/social","/link-social"].includes(path) && request.method === "POST") {
          const body = await request.clone().json();
          if (body.provider !== "google" || !google?.clientId || !google?.clientSecret)
            throw new AuthServerError("This sign-in method is not available.", {status:400,code:"PROVIDER_UNAVAILABLE"});
        }
        await beforeRequest({request,path,getSession});
        let providerRequest = request;
        if (path === "/revoke-session" && request.method === "POST") {
          const body = await request.clone().json();
          const sessions = await auth.api.listSessions({headers:request.headers});
          const target = sessions.find(item => item.id === body.id);
          if (!target) throw new AuthServerError("Session not found.", {status:404,code:"NOT_FOUND"});
          const headers = new Headers(request.headers);
          headers.delete("content-length");
          providerRequest = new Request(request.url,{method:"POST",headers,body:JSON.stringify({token:target.token})});
        }
        // The provider consumes the request stream. Keep a bounded clone for
        // the host's post-verification replay/audit hook before calling it.
        const verifiedRequest = request.method === "POST" &&
          ["/two-factor/verify-totp","/two-factor/verify-backup-code"].includes(path) ? request.clone() : null;
        const response = await auth.handler(providerRequest);
        if (request.method === "POST" && !response.ok &&
          ["/two-factor/verify-totp","/two-factor/verify-backup-code"].includes(path))
          await onMfaFailed(await getSession(request.headers));
        if (request.method === "POST" && response.ok &&
          ["/two-factor/verify-totp","/two-factor/verify-backup-code"].includes(path)) {
          // A credential challenge can create a NEW session. Verify the actual signed
          // response cookies via the provider before marking that session as MFA-verified.
          const headers = mergeResponseCookies(request.headers, response.headers);
          const session = await getSession(headers);
          if (!session?.session || !session.user?.twoFactorEnabled)
            throw new AuthServerError("Verification did not create a valid session.", {status:401,code:"MFA_REQUIRED"});
          await onMfaVerified(session, {request:verifiedRequest,path});
        }
        const headers = new Headers(response.headers);
        headers.set("Cache-Control","no-store");
        headers.set("Referrer-Policy","no-referrer");
        if (headers.get("content-type")?.includes("application/json")) {
          let body = await response.json();
          if (response.ok && body && !Array.isArray(body)) { delete body.token; if(body.session)delete body.session.token; }
          if (response.ok && path === "/list-sessions" && Array.isArray(body))
            body = body.map(({id,createdAt,expiresAt,ipAddress,userAgent}) =>
              ({id,createdAt,expiresAt,ipAddress,userAgent}));
          return new Response(JSON.stringify(response.ok ? {data:body} :
            {error:{code:body.code || "AUTH_ERROR",message:body.message || "Unable to complete sign-in."}}),
            {status:response.status,headers});
        }
        return new Response(response.body,{status:response.status,headers});
      } catch (error) {
        if (error instanceof AuthServerError)
          return Response.json({error:{code:error.code,message:error.message}},
            {status:error.status,headers:{"Cache-Control":"no-store"}});
        throw error;
      }
    },
  });
}

function mergeResponseCookies(original, returned) {
  const headers = new Headers(original);
  const cookies = new Map((headers.get("Cookie") || "").split(/;\s*/).filter(Boolean).map(item => {
    const index = item.indexOf("=");
    return [item.slice(0,index),item.slice(index + 1)];
  }));
  const values = typeof returned.getSetCookie === "function" ? returned.getSetCookie() :
    (returned.get("Set-Cookie") || "").split(/,(?=\s*[^;,\s]+=)/);
  for (const value of values) {
    const pair = value.split(";")[0].trim(), index = pair.indexOf("=");
    if (index > 0) cookies.set(pair.slice(0,index),pair.slice(index + 1));
  }
  headers.set("Cookie",[...cookies].map(([name,value]) => name + "=" + value).join("; "));
  return headers;
}
