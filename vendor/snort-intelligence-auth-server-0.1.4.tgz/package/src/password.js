import {randomBytes, scrypt, timingSafeEqual} from "node:crypto";
import {Buffer} from "node:buffer";

// OWASP's 32 MiB scrypt profile. Never accept arbitrary costs from stored input.
const CURRENT = Object.freeze({N:32768, r:8, p:3});
const LEGACY = Object.freeze({N:16384, r:16, p:1});
const PREFIX = "scrypt$v1$32768$8$3$";
const HEX_SALT = /^[0-9a-f]{32}$/;
const HEX_KEY = /^[0-9a-f]{128}$/;

function derive(password, salt, cost) {
  return new Promise((resolve,reject) => {
    // NFKC and the hex salt as text preserve Better Auth's previous semantics.
    scrypt(password.normalize("NFKC"), salt, 64, {...cost, maxmem:64 * 1024 * 1024},
      (error,key) => error ? reject(error) : resolve(key));
  });
}

export async function hashPassword(password) {
  if (typeof password !== "string" || password.length < 15 || password.length > 128)
    throw new Error("Password must contain 15 to 128 characters.");
  const salt = randomBytes(16).toString("hex");
  const key = await derive(password,salt,CURRENT);
  try { return PREFIX + salt + "$" + key.toString("hex"); }
  finally { key.fill(0); }
}

export async function verifyPassword({hash,password}) {
  if (typeof password !== "string" || password.length > 128 || typeof hash !== "string") return false;
  let salt, encoded, cost;
  if (hash.startsWith(PREFIX)) {
    const parts = hash.slice(PREFIX.length).split("$");
    if (parts.length !== 2) return false;
    [salt,encoded] = parts;
    cost = CURRENT;
  } else {
    // Read compatibility only for the pinned provider's old salt:key format.
    const parts = hash.split(":");
    if (parts.length !== 2) return false;
    [salt,encoded] = parts;
    cost = LEGACY;
  }
  if (!HEX_SALT.test(salt) || !HEX_KEY.test(encoded)) return false;
  const expected = Buffer.from(encoded,"hex");
  const actual = await derive(password,salt,cost);
  try { return timingSafeEqual(actual,expected); }
  finally { actual.fill(0); expected.fill(0); }
}
